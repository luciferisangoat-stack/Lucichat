LuciChat Real AI (local)
========================
This version uses WebLLM to run a small language model in the browser, without a cloud API key.

Model: Llama-3.2-1B-Instruct-q4f32_1-MLC
The model is about 705 MB and the browser also needs enough GPU memory/storage. The first load can take a while. WebLLM requires a WebGPU-compatible browser.

Creator PIN: 1234
Change it in index.html before publishing.

Important:
- This is local browser AI, not a paid cloud API.
- The model downloads from the internet the first time and is cached by the browser.
- If the phone/browser does not support WebGPU, this version cannot run the local model.
- Opening an HTML file directly may restrict module/network loading on some browsers. If that happens, the app needs to be hosted on a normal HTTPS site.
